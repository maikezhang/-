package com.product.demo.utils;



import java.io.Serializable;

import com.alibaba.fastjson.JSONObject;

/**
 * Description:
 * Created with IntelliJ IDEA.
 * User: zhangyingjie
 * Date: 2018/1/1
 * Time: 下午10:04
 */
public class Base implements Serializable {

    protected static final JSONObject GSON=new JSONObject();

    @Override
    public String toString(){
        return GSON.toJSONString(this);
    }
}
