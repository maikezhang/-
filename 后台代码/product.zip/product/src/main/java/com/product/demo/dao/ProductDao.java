package com.product.demo.dao;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Param;

import com.product.demo.bean.Product;

@Mapper
public interface ProductDao {

	//@Select("select * from tb_product")
    @Select("<script>"+
    "select * from tb_product where 1=1 <if test='id!=null'> and id =#{id} </if>"
    + "</script> ")
	Product  getProduct(@Param("id") String id);
    
	@Select("select * from tb_product")
	List<Product>  getProductList();
	
	@Insert("insert into tb_product tp                              "
		  + "(tp.id,tp.name,tp.`desc`,tp.price,tp.filePath)         "
		  + "values                                                 " 
		  + "(#{id},#{name},#{desc},#{price},#{filePath})           ")
	void addProduct(Product pro);
}
